package overloadingPrograms;

public class Demo1Add {
	public int add(int a,int b)
	{
		return a+b;
	}
	//overlaoding the add() method
	public int add(int a,int b,int c)
	{
		return a+b+c;
	}
	public static int sub(int a,int b)
	{
		return a-b;
	}
	public static double sub(Double a,int b)
	{
		return a-b;
	}
	public static void main(String[] args) 
	{
//		System.out.println(Demo1Add.add(2,2));		//can't make static reference to nonstatic method add
		Demo1Add d=new Demo1Add();					//we have to create object 
		System.out.println("Addition of 2 args: "+d.add(2, 2));	//Addition of 2 args: 4
		System.out.println("Addition of 3 args: "+d.add(2,2,2));	//Addition of 3 args: 6
		System.out.println(d.sub(4.2, 2));			//2.2
		System.out.println("Substraction: "+Demo1Add.sub(4.2, 2));	//static reference to static method 
																	//Substraction: 2.2
		System.out.println("Substraction: "+Demo1Add.sub(5,3));		//Substraction: 2
		
	}

}
