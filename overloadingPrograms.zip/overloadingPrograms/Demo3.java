package overloadingPrograms;

public class Demo3 {

	public static void main(String[] args) 
	{
		System.out.println("Main with String");
	}
	public static void main(String args)
	{
		System.out.println("Main with string");
	}
	public static void main()
	{
		System.out.println("Main without arg");
	}
}

/*
Output
Main with String
JVM calls main() method which receives string array as arguments
*/