package overloadingPrograms;

public class Demo2Test {

	// Valid Overlaoded methods
	public void fly(int numMiles) { 
		System.out.println("");
	}
	public void fly(short numFeet) { }
	public boolean fly() { return false; }
	void fly(int numMiles, short numFeet) { }
	public void fly(short numFeet, int numMiles) throws Exception { }

	// DOES NOT COMPILE
//	public void fly(int numMiles) { }
//	public int fly(int numMiles) { } 

	public static void main(String[] args)
	{
		Demo2Test d=new Demo2Test();
		System.out.println(d.fly());
		
		
	}
}
